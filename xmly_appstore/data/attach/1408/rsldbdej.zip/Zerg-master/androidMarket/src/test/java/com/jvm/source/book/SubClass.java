package com.jvm.source.book;

public class SubClass extends SuperClass {
	static {
		System.out.println("SubClass init!");
	}
}
