package com.jdk8.features;


public class TestInterfaceImpl implements TestInterface {
	public static void main(String[] args) {
		TestInterfaceImpl t = new TestInterfaceImpl();
		t.test();
		t.test2();
	}
}
