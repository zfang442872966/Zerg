package com.jdk8.features;

@FunctionalInterface
public interface MethodQuote {
	public int lambdaTest(int a, int b);
}
