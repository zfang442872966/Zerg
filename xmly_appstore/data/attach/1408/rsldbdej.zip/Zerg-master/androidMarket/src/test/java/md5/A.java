package md5;

public class A {
}
